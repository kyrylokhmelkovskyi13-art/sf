package ru.chatmoderator;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import ru.chatmoderator.config.ModConfig;
import ru.chatmoderator.core.ChatMessage;
import ru.chatmoderator.core.RuleEngine;
import ru.chatmoderator.core.Violation;
import ru.chatmoderator.ui.SettingsScreen;
import ru.chatmoderator.evidence.RegionCaptureScreen;

import java.time.Instant;
import java.util.List;
import java.util.ArrayDeque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/** Client-only moderation helper. It flags candidates and never issues punishments. */
public final class ChatModeratorClient implements ClientModInitializer {
    public static ModConfig CONFIG;
    public static final RuleEngine RULE_ENGINE = new RuleEngine();
    private static final CopyOnWriteArrayList<FlaggedMessage> FLAGGED = new CopyOnWriteArrayList<>();
    private static volatile String previousText = "";
    private static volatile long previousAt;
    private static volatile String previousSender = "";
    private static final Map<String, ArrayDeque<Long>> RECENT_BY_SENDER = new ConcurrentHashMap<>();

    private static KeyMapping commandKey;
    private static KeyMapping settingsKey;
    private static KeyMapping evidenceKey;
    private static volatile FlaggedMessage selectedFlagged;

    @Override
    public void onInitializeClient() {
        CONFIG = ModConfig.load();

        KeyMapping.Category category = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath("chatmoderator", "main")
        );
        commandKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.chatmoderator.insert_command", InputConstants.Type.KEYSYM, InputConstants.KEY_F6, category
        ));
        settingsKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.chatmoderator.settings", InputConstants.Type.KEYSYM, InputConstants.KEY_F8, category
        ));
        evidenceKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.chatmoderator.evidence", InputConstants.Type.KEYSYM, InputConstants.KEY_F7, category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (commandKey.consumeClick()) {
                if (client.player == null) continue;
                FlaggedMessage latest = selectedOrLatest();
                if (latest == null || latest.message().sender().isBlank()) {
                    client.player.sendSystemMessage(Component.literal("[ChatModerator] Нет найденного сообщения с определённым ником."));
                    continue;
                }
                String playerName = latest.message().sender().trim();
                // Never interpolate arbitrary tellraw/display text into a command.
                if (!playerName.matches("[A-Za-z0-9_]{1,16}")) {
                    client.player.sendSystemMessage(Component.literal(
                        "[ChatModerator] Ник нельзя безопасно подставить в команду: " + playerName
                    ));
                    continue;
                }
                String template = CONFIG.commandTemplate == null ? "/tempute {player}" : CONFIG.commandTemplate.trim();
                if (!template.startsWith("/") || !template.contains("{player}")) {
                    client.player.sendSystemMessage(Component.literal(
                        "[ChatModerator] Проверь commandTemplate: нужен слэш и {player}."
                    ));
                    continue;
                }
                String command = template.replace("{player}", playerName);
                // Open chat with a prefilled command; do not submit it.
                client.gui.setScreen(new ChatScreen(command, false));
            }
            while (settingsKey.consumeClick()) {
                client.gui.setScreen(new SettingsScreen(client.gui.screen(), CONFIG));
            }
            while (evidenceKey.consumeClick()) {
                if (client.player != null) client.gui.setScreen(new RegionCaptureScreen(client.gui.screen()));
            }
        });

        ClientReceiveMessageEvents.CHAT.register((message, playerChatMessage, sender, boundChatType, timestamp) -> {
            if (CONFIG.inspectPlayerMessages) {
                String name = sender == null ? "" : sender.getName();
                inspect(name, message, timestamp == null ? Instant.now() : timestamp);
            }
        });
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (CONFIG.inspectServerMessages && !overlay) inspect("", message, Instant.now());
        });
    }

    private static void inspect(String sender, Component component, Instant timestamp) {
        if (CONFIG == null || !CONFIG.scannerEnabled) return;
        String text = component.getString();
        sender = sender == null ? "" : sender;
        long now = System.currentTimeMillis();
        String previous = sender.equals(previousSender) && now - previousAt <= CONFIG.spamWindowSeconds * 1000L ? previousText : null;
        List<Violation> detected = new java.util.ArrayList<>(RULE_ENGINE.inspect(text, previous, sender, CONFIG.exceptions));
        if (sender != null && !sender.isBlank()) {
            String senderKey = sender.toLowerCase(java.util.Locale.ROOT);
            ArrayDeque<Long> recent = RECENT_BY_SENDER.computeIfAbsent(senderKey, ignored -> new ArrayDeque<>());
            synchronized (recent) {
                long cutoff = now - CONFIG.spamWindowSeconds * 1000L;
                while (!recent.isEmpty() && recent.peekFirst() < cutoff) recent.removeFirst();
                recent.addLast(now);
                if (recent.size() >= CONFIG.spamMessageThreshold && detected.stream().noneMatch(v -> v.ruleId().equals("3.4"))) {
                    detected.add(new Violation("3.4", "Возможный флуд: " + recent.size() + " сообщений за " + CONFIG.spamWindowSeconds + " сек.", .75));
                }
            }
        }
        detected.removeIf(v -> !CONFIG.isRuleEnabled(v.ruleId()));
        List<Violation> violations = List.copyOf(detected);
        previousText = text;
        previousSender = sender;
        previousAt = now;
        if (!violations.isEmpty()) {
            FlaggedMessage flagged = new FlaggedMessage(new ChatMessage(sender, text, timestamp.toEpochMilli()), violations);
            FLAGGED.add(0, flagged);
            while (FLAGGED.size() > 100) FLAGGED.remove(FLAGGED.size() - 1);
            if (CONFIG.showCandidatesInChat && net.minecraft.client.Minecraft.getInstance().player != null) {
                String rules = violations.stream().map(Violation::ruleId).distinct().reduce((a, b) -> a + ", " + b).orElse("?");
                String who = sender.isBlank() ? "сообщение сервера" : sender;
                net.minecraft.client.Minecraft.getInstance().player.sendSystemMessage(
                    Component.literal("[ChatModerator] Возможное нарушение " + rules + " — " + who + ". F6: вставить команду.")
                );
            }
        }
    }

    public static List<FlaggedMessage> flaggedMessages() { return List.copyOf(FLAGGED); }
    public static void selectFlagged(FlaggedMessage entry) { selectedFlagged = entry; }
    public static FlaggedMessage selectedOrLatest() {
        FlaggedMessage selected = selectedFlagged;
        if (selected != null && FLAGGED.contains(selected)) return selected;
        return FLAGGED.stream().filter(f -> f.message().sender() != null && !f.message().sender().isBlank()).findFirst().orElse(null);
    }
    public record FlaggedMessage(ChatMessage message, List<Violation> violations) {}
}
