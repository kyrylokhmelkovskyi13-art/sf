package ru.chatmoderator.evidence;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ru.chatmoderator.ChatModeratorClient;
import ru.chatmoderator.integration.DiscordWebhookClient;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;

/**
 * F7 evidence selector. Drag a rectangle tightly around one rendered Minecraft chat message.
 * Robot captures the actual desktop pixels; it does not redraw or reconstruct chat text.
 * This deliberately requires a manual rectangle because chat rows can wrap and server tellraw
 * components can have arbitrary formatting.
 */
public final class RegionCaptureScreen extends Screen {
    private final Screen parent;
    private double startX = -1, startY = -1, endX = -1, endY = -1;
    private boolean dragging;

    public RegionCaptureScreen(Screen parent) {
        super(Component.literal("ChatModerator — выдели сообщение мышью"));
        this.parent = parent;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);
        g.fill(0, 0, width, height, 0x44000000);
        g.drawCenteredString(Minecraft.getInstance().font,
            "Зажми ЛКМ и выдели только сообщение чата; Enter — сохранить, Esc — отмена",
            width / 2, 12, 0xFFFFFFFF);
        if (startX >= 0 && endX >= 0) {
            int x1 = (int)Math.min(startX, endX), y1 = (int)Math.min(startY, endY);
            int x2 = (int)Math.max(startX, endX), y2 = (int)Math.max(startY, endY);
            g.fill(x1, y1, x2, y2, 0x33FF3333);
            g.outline(x1, y1, Math.max(1, x2 - x1), Math.max(1, y2 - y1), 0xFFFF5555);
        }
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button != 0) return super.mouseClicked(x, y, button);
        startX = endX = x; startY = endY = y; dragging = true;
        return true;
    }

    @Override
    public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        if (dragging && button == 0) { endX = x; endY = y; return true; }
        return super.mouseDragged(x, y, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double x, double y, int button) {
        if (button == 0 && dragging) { endX = x; endY = y; dragging = false; return true; }
        return super.mouseReleased(x, y, button);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        if (event.key() == 256) { Minecraft.getInstance().gui.setScreen(parent); return true; }
        if (event.key() == 257 || event.key() == 335) { capture(); return true; }
        return super.keyPressed(event);
    }

    private void capture() {
        if (startX < 0 || endX < 0) { status("Сначала выдели область мышью"); return; }
        int guiX1 = (int)Math.floor(Math.min(startX, endX));
        int guiY1 = (int)Math.floor(Math.min(startY, endY));
        int guiX2 = (int)Math.ceil(Math.max(startX, endX));
        int guiY2 = (int)Math.ceil(Math.max(startY, endY));
        if (guiX2 - guiX1 < 8 || guiY2 - guiY1 < 8) { status("Область слишком маленькая"); return; }
        Minecraft mc = Minecraft.getInstance();
        var window = mc.getWindow();
        Rectangle gameWindow = new Rectangle(window.getX(), window.getY(), window.getWidth(), window.getHeight());
        Rectangle bounds = CaptureBounds.fromGui(gameWindow, window.getScaledWidth(), window.getScaledHeight(),
            guiX1, guiY1, guiX2, guiY2);
        if (bounds.width < 8 || bounds.height < 8) { status("Выделение вне окна Minecraft"); return; }
        mc.gui.setScreen(parent);
        CompletableFuture.runAsync(() -> {
            try {
                // Let Minecraft redraw the parent screen so the selection overlay is absent.
                Thread.sleep(250);
                BufferedImage shot = new Robot().createScreenCapture(bounds);
                Path gameDir = mc.gameDirectory.toPath().toAbsolutePath().normalize();
                Path dir = gameDir.resolve(ChatModeratorClient.CONFIG.evidenceFolder).normalize();
                if (!dir.startsWith(gameDir)) throw new IOException("Папка доказательств должна находиться внутри папки игры");
                Files.createDirectories(dir);
                String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS"));
                Path file = dir.resolve("chat-evidence-" + stamp + ".png");
                if (!ImageIO.write(shot, "png", file.toFile())) throw new IOException("PNG-кодировщик недоступен");
                boolean upload = ChatModeratorClient.CONFIG.uploadEvidenceToDiscord
                    && ChatModeratorClient.CONFIG.discordWebhook != null
                    && !ChatModeratorClient.CONFIG.discordWebhook.isBlank();
                String uploadStatus = "";
                if (upload) {
                    try {
                        DiscordWebhookClient.sendImage(ChatModeratorClient.CONFIG.discordWebhook, file,
                            "ChatModerator: выделенный фрагмент чата. Проверьте контекст вручную.");
                        uploadStatus = "; Discord: отправлено";
                    } catch (Exception uploadError) {
                        uploadStatus = "; Discord: ошибка отправки (" + uploadError.getClass().getSimpleName() + ")";
                    }
                }
                final String result = "[ChatModerator] PNG сохранён: " + file.getFileName() + uploadStatus;
                mc.execute(() -> { if (mc.player != null) mc.player.sendSystemMessage(Component.literal(result)); });
            } catch (Exception e) {
                String error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                mc.execute(() -> { if (mc.player != null) mc.player.sendSystemMessage(Component.literal(
                    "[ChatModerator] Не удалось сделать доказательство: " + error)); });
            }
        });
    }

    private void status(String text) {
        if (minecraft != null && minecraft.player != null)
            minecraft.player.sendSystemMessage(Component.literal("[ChatModerator] " + text));
    }

    @Override public void onClose() { Minecraft.getInstance().gui.setScreen(parent); }
}
