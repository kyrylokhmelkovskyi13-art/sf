# Security notes

- Never commit a Discord webhook URL.
- Store webhook credentials only in the local config file.
- Evidence upload must be user-triggered and must not include unrelated private chat.
- No automatic punishments or command execution are permitted.
