@echo off
setlocal
where java >nul 2>nul || (echo ERROR: Install JDK 25 and add java to PATH.& exit /b 1)
for /f "tokens=3" %%a in ('java -XshowSettings:properties -version 2^>^&1 ^| findstr "java.specification.version"') do set JAVA_MAJOR=%%a
if not "%JAVA_MAJOR%"=="25" (echo ERROR: Minecraft 26.2 build requires JDK 25. Detected Java major: %JAVA_MAJOR%.& exit /b 1)
where gradle >nul 2>nul || (echo ERROR: Install Gradle 9.5.1 and add gradle to PATH.& exit /b 1)
gradle --version | findstr "9.5.1" >nul || (echo ERROR: Use Gradle 9.5.1.& exit /b 1)
gradle clean ruleEngineTest build
if errorlevel 1 exit /b %errorlevel%
echo Build output: build\libs\
