#!/usr/bin/env bash
set -euo pipefail
command -v java >/dev/null || { echo "Install JDK 25" >&2; exit 1; }
major="$(java -XshowSettings:properties -version 2>&1 | awk '/java.specification.version =/ {print $3; exit}')"
[[ "$major" == "25" ]] || { echo "Minecraft 26.2 requires JDK 25; found ${major:-unknown}" >&2; exit 1; }
command -v gradle >/dev/null || { echo "Install Gradle 9.5.1" >&2; exit 1; }
gradle --version | grep -q 'Gradle 9.5.1' || { echo "Use Gradle 9.5.1" >&2; exit 1; }
gradle clean ruleEngineTest build
echo "Build output: build/libs/"
