package ru.chatmoderator.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("chatmoderator.json");

    public boolean scannerEnabled = true;
    public boolean showCandidatesInChat = true;
    public String commandTemplate = "/tempute {player}";
    public String discordWebhook = ""; // Keep private; never commit a real webhook URL.
    public boolean uploadEvidenceToDiscord = false;
    public int spamWindowSeconds = 8;
    public int spamMessageThreshold = 4;
    public boolean inspectServerMessages = true;
    public boolean inspectPlayerMessages = true;
    public String evidenceFolder = "chatmoderator/evidence";
    public List<String> exceptions = new ArrayList<>(List.of(
        "ноль","нулина","нуб","бот","рак","слитый","слабый","анскил","нефор",
        "позорище","лох","дурак","дурень","бездарь","лоускил","руинер","чушпан",
        "тюфяк","шляпа","тормоз","воздухан","чайник","трус","сопляк"
    ));
    public String keyCommand = "F6";
    public String keyEvidence = "F7";
    public String keySettings = "F8";
    /** Per-rule switches; absent entries default to enabled for backwards compatibility. */
    public Map<String, Boolean> enabledRules = new LinkedHashMap<>();

    public boolean isRuleEnabled(String id) { return enabledRules == null || !enabledRules.containsKey(id) || Boolean.TRUE.equals(enabledRules.get(id)); }
    public void setRuleEnabled(String id, boolean enabled) { if (enabledRules == null) enabledRules = new LinkedHashMap<>(); enabledRules.put(id, enabled); save(); }

    public static ModConfig load() {
        try {
            if (Files.exists(FILE)) {
                ModConfig c = GSON.fromJson(Files.readString(FILE), ModConfig.class);
                if (c != null) { c.normalizeDefaults(); return c; }
            }
        } catch (Exception ignored) {}
        ModConfig c = new ModConfig();
        c.save();
        return c;
    }

    private void normalizeDefaults() {
        if (commandTemplate == null || commandTemplate.isBlank()) commandTemplate = "/tempute {player}";
        commandTemplate = commandTemplate.trim();
        if (!commandTemplate.startsWith("/") || !commandTemplate.contains("{player}"))
            commandTemplate = "/tempute {player}";
        if (exceptions == null) exceptions = new ArrayList<>();
        if (enabledRules == null) enabledRules = new LinkedHashMap<>();
        if (evidenceFolder == null || evidenceFolder.isBlank()) evidenceFolder = "chatmoderator/evidence";
        if (spamWindowSeconds < 1) spamWindowSeconds = 8;
        if (spamMessageThreshold < 2) spamMessageThreshold = 4;
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException e) {
            throw new IllegalStateException("Could not save ChatModerator config", e);
        }
    }
}
