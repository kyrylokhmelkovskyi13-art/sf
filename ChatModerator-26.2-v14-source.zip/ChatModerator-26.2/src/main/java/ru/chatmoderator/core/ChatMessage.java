package ru.chatmoderator.core;

public record ChatMessage(String sender, String plainText, long receivedAtMillis) {}
