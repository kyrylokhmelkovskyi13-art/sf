package ru.chatmoderator.core;

public record ChatRule(String id, String title, String punishment, String explanation) {}
