package ru.chatmoderator.core;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Heuristic candidate detector. Never performs moderation actions. */
public final class RuleEngine {
    private static final Pattern WORD = Pattern.compile("[\\p{L}\\p{N}_]+", Pattern.UNICODE_CHARACTER_CLASS);
    private static final Pattern STAFF_CLAIM = Pattern.compile("(?iu)(?:я\\s+)?(?:админ(?:истратор)?|модер(?:атор)?|куратор|хелпер|сотрудник)\\b.{0,35}(?:бан|мут|предупрежден|накаж|провер|выдам|сниму)");
    private static final Set<String> BUILTIN_EXCEPTIONS = Set.of(
        "ноль","нулина","нуб","бот","рак","слитый","слабый","анскил","нефор","позорище",
        "лох","дурак","дурень","бездарь","лоускил","руинер","чушпан","тюфяк","шляпа",
        "тормоз","воздухан","чайник","трус","сопляк"
    );
    private static final List<String> INSULTS = List.of("ебан", "ебл", "сука", "мраз", "гнид", "пидор", "долбо", "уеб", "чмо");
    private static final List<String> FAMILY = List.of("твою мать", "твоей матери", "мать твою", "твою маму", "твоего отца", "твоего батьк");
    private static final List<String> AD_HINTS = List.of("discord.gg/", "discord.com/invite/", "t.me/", "vk.com/", "youtube.com/", "наш сервер", "заходите на проект");
    private static final List<String> POLITICS_HINTS = List.of("нацист", "фашист", "ненавижу народ", "всех [национальность]");
    private static final List<String> SERVER_CRITICISM = List.of("админы туп", "администрация туп", "модеры туп", "сервер помойка", "донатная помойка", "админ бесполез");
    private static final List<String> PROVOCATION = List.of("нарушай правила", "обойди правила", "давай заспамим", "оскорби админа", "ломай правила");
    private static final List<String> BEGGING = List.of("дай денег", "дай ресур", "подари", "скинь предмет", "выдай мне", "можно халяв", "подарите", "дайте вещей");

    public List<Violation> inspect(String raw, String previousRaw) { return inspect(raw, previousRaw, "", List.of()); }

    public List<Violation> inspect(String raw, String previousRaw, String sender, List<String> configuredExceptions) {
        if (raw == null || raw.isBlank()) return List.of();
        String text = normalize(raw);
        // Server-provided hidden-filter notice is metadata, not player speech.
        if (text.equals("сообщения скрытые фильтром") || text.equals("сообщение скрыто фильтром")) return List.of();
        Set<String> exceptions = new HashSet<>(BUILTIN_EXCEPTIONS);
        if (configuredExceptions != null) {
            configuredExceptions.stream()
                .filter(Objects::nonNull)
                .map(RuleEngine::normalize)
                .filter(value -> !value.isBlank())
                .forEach(exceptions::add);
        }
        List<Violation> out = new ArrayList<>();

        long letters = raw.codePoints().filter(Character::isLetter).count();
        long upper = raw.codePoints().filter(Character::isLetter).filter(Character::isUpperCase).count();
        if (letters >= 5 && upper * 100.0 / letters > 70.0) add(out, "3.2", "Более 70% букв заглавные", .99);

        if (containsInsult(text, exceptions)) add(out, "3.1", "Возможное оскорбление; проверь контекст", .65);
        if (containsAny(text, FAMILY)) add(out, "3.3", "Возможное упоминание родственников", .78);
        if (containsAny(text, AD_HINTS) || text.matches(".*https?://\\S+.*")) add(out, "3.5", "Возможная реклама/ссылка на сторонний проект", .70);
        if (containsAny(text, POLITICS_HINTS)) add(out, "3.8", "Возможный политический/межнациональный конфликтный контекст", .35);
        if (containsAny(text, SERVER_CRITICISM)) add(out, "3.6", "Возможная критика сервера или администрации", .50);
        if (STAFF_CLAIM.matcher(text).find()) add(out, "3.7", "Возможная выдача себя за персонал", .65);
        if (containsAny(text, PROVOCATION)) add(out, "3.9", "Возможное подстрекательство к нарушению правил", .65);
        if (containsAny(text, BEGGING) || looksLikeBegging(text)) add(out, "3.10", "Возможное попрошайничество", .50);
        if (previousRaw != null && normalize(previousRaw).equals(text) && text.length() > 2) add(out, "3.4", "Повтор одинакового сообщения подряд", .85);
        return List.copyOf(out);
    }

    private static boolean containsInsult(String text, Set<String> exceptions) {
        Matcher m = WORD.matcher(text);
        while (m.find()) {
            String word = m.group();
            if (exceptions.contains(word)) continue;
            for (String root : INSULTS) if (word.contains(root)) return true;
        }
        return false;
    }
    private static boolean looksLikeBegging(String s) {
        return s.matches("(?U).*(?<![\\p{L}\\p{N}_])(дай|дайте|подари|подарите|скинь|скиньте|выдай|выдайте)(?![\\p{L}\\p{N}_]).{0,45}(?<![\\p{L}\\p{N}_])(мне|денег|ресурс|предмет|вещ|донат|привилег|ранг)(?![\\p{L}\\p{N}_]).*");
    }
    private static void add(List<Violation> out, String id, String reason, double confidence) { out.add(new Violation(id, reason, confidence)); }
    private static boolean containsAny(String s, List<String> needles) { return needles.stream().anyMatch(s::contains); }
    private static String normalize(String s) { return Normalizer.normalize(s, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("[\\u200B-\\u200D\\uFEFF]", "").replaceAll("\\s+", " ").trim(); }
}
