package ru.chatmoderator.core;

public record Violation(String ruleId, String reason, double confidence) {}
