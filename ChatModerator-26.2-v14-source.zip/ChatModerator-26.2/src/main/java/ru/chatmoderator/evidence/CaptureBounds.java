package ru.chatmoderator.evidence;

import java.awt.Rectangle;

/** Pure coordinate conversion used by F7; desktop coordinates are required by AWT Robot. */
public final class CaptureBounds {
    private CaptureBounds() {}

    public static Rectangle fromGui(Rectangle gameWindow, int scaledWidth, int scaledHeight,
                                    int guiX1, int guiY1, int guiX2, int guiY2) {
        if (gameWindow == null || gameWindow.width <= 0 || gameWindow.height <= 0
                || scaledWidth <= 0 || scaledHeight <= 0) return new Rectangle();
        int left = Math.min(guiX1, guiX2);
        int top = Math.min(guiY1, guiY2);
        int right = Math.max(guiX1, guiX2);
        int bottom = Math.max(guiY1, guiY2);
        double sx = gameWindow.width / (double) scaledWidth;
        double sy = gameWindow.height / (double) scaledHeight;
        int x = gameWindow.x + (int) Math.floor(left * sx);
        int y = gameWindow.y + (int) Math.floor(top * sy);
        int r = gameWindow.x + (int) Math.ceil(right * sx);
        int b = gameWindow.y + (int) Math.ceil(bottom * sy);
        return new Rectangle(x, y, Math.max(0, r - x), Math.max(0, b - y)).intersection(gameWindow);
    }
}
