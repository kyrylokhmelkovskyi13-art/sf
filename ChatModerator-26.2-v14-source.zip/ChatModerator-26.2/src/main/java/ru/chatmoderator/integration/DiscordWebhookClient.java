package ru.chatmoderator.integration;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.UUID;

/** Sends a user-selected evidence image to a Discord webhook. Never captures the screen itself. */
public final class DiscordWebhookClient {
    private static final HttpClient HTTP = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10)).build();

    private DiscordWebhookClient() {}

    public static void sendImage(String webhookUrl, Path image, String caption)
            throws IOException, InterruptedException {
        if (webhookUrl == null || webhookUrl.isBlank())
            throw new IllegalArgumentException("Discord webhook is not configured");
        URI uri = URI.create(webhookUrl.trim());
        String host = uri.getHost();
        if (!"discord.com".equalsIgnoreCase(host) && !"discordapp.com".equalsIgnoreCase(host))
            throw new IllegalArgumentException("Only official Discord webhook hosts are allowed");
        if (!uri.getPath().matches("/api/webhooks/[0-9]+/[^/]+/?"))
            throw new IllegalArgumentException("URL is not a Discord webhook endpoint");
        if (!Files.isRegularFile(image) || Files.size(image) > 8L * 1024 * 1024)
            throw new IOException("Evidence file is missing or larger than 8 MiB");

        String boundary = "----ChatModerator" + UUID.randomUUID().toString().replace("-", "");
        byte[] file = Files.readAllBytes(image);
        String filename = image.getFileName().toString().replaceAll("[^A-Za-z0-9._-]", "_");
        String safeCaption = caption == null ? "" : caption.replace("\r", " ").replace("\n", " ").replace("\t", " ");
        byte[] head = ("--" + boundary + "\r\n" +
            "Content-Disposition: form-data; name=\"payload_json\"\r\n" +
            "Content-Type: application/json; charset=utf-8\r\n\r\n" +
            "{\"content\":\"" + jsonEscape(safeCaption) + "\"}\r\n" +
            "--" + boundary + "\r\n" +
            "Content-Disposition: form-data; name=\"files[0]\"; filename=\"" + filename + "\"\r\n" +
            "Content-Type: image/png\r\n\r\n").getBytes(StandardCharsets.UTF_8);
        byte[] tail = ("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8);
        byte[] body = new byte[head.length + file.length + tail.length];
        System.arraycopy(head, 0, body, 0, head.length);
        System.arraycopy(file, 0, body, head.length, file.length);
        System.arraycopy(tail, 0, body, head.length + file.length, tail.length);

        HttpRequest request = HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(20))
            .header("Content-Type", "multipart/form-data; boundary=" + boundary)
            .POST(HttpRequest.BodyPublishers.ofByteArray(body)).build();
        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300)
            throw new IOException("Discord returned HTTP " + response.statusCode());
    }

    private static String jsonEscape(String value) {
        StringBuilder escaped = new StringBuilder(value.length() + 16);
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '\\' -> escaped.append("\\\\");
                case '\"' -> escaped.append("\\\"");
                case '\b' -> escaped.append("\\b");
                case '\f' -> escaped.append("\\f");
                case '\n' -> escaped.append("\\n");
                case '\r' -> escaped.append("\\r");
                case '\t' -> escaped.append("\\t");
                default -> {
                    if (c < 0x20) escaped.append(String.format("\\u%04x", (int) c));
                    else escaped.append(c);
                }
            }
        }
        return escaped.toString();
    }
}
