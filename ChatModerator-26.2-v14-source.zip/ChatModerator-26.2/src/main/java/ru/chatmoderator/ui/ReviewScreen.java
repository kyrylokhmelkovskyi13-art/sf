package ru.chatmoderator.ui;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ru.chatmoderator.ChatModeratorClient;

import java.util.List;

/** Human review list. Selecting a row makes it the target for F6; no punishment is sent. */
public final class ReviewScreen extends Screen {
    private final Screen parent;
    private final List<ChatModeratorClient.FlaggedMessage> entries;

    public ReviewScreen(Screen parent) {
        super(Component.literal("ChatModerator — найденные сообщения"));
        this.parent = parent;
        this.entries = ChatModeratorClient.flaggedMessages();
    }

    @Override protected void init() {
        int left = Math.max(8, width / 2 - 190);
        int top = 38;
        int shown = Math.min(entries.size(), 9);
        for (int i = 0; i < shown; i++) {
            final ChatModeratorClient.FlaggedMessage entry = entries.get(i);
            String sender = entry.message().sender().isBlank() ? "сервер" : entry.message().sender();
            String rules = entry.violations().stream().map(v -> v.ruleId()).distinct().reduce((a,b) -> a + "," + b).orElse("?");
            String snippet = entry.message().plainText().replace('\n', ' ');
            if (snippet.length() > 34) snippet = snippet.substring(0, 34) + "…";
            String label = (i + 1) + ". " + sender + " [" + rules + "] " + snippet;
            int y = top + i * 27;
            addRenderableWidget(Button.builder(Component.literal(label), b -> {
                ChatModeratorClient.selectFlagged(entry);
                b.setMessage(Component.literal("✓ " + label));
            }).bounds(left, y, 380, 22).build());
        }
        if (entries.isEmpty()) {
            addRenderableWidget(Button.builder(Component.literal("Пока нет отмеченных сообщений"), b -> {})
                .bounds(left, top, 380, 22).build());
        }
        addRenderableWidget(Button.builder(Component.literal("F6 — вставить /tempute для выбранного игрока"), b -> {
            if (minecraft != null && minecraft.player != null) {
                var selected = ChatModeratorClient.selectedOrLatest();
                if (selected != null && !selected.message().sender().isBlank()) {
                    String command = ChatModeratorClient.CONFIG.commandTemplate.replace("{player}", selected.message().sender());
                    minecraft.gui.setScreen(new net.minecraft.client.gui.screens.ChatScreen(command, false));
                }
            }
        }).bounds(left, top + 9 * 27 + 4, 380, 22).build());
        addRenderableWidget(Button.builder(Component.literal("Закрыть"), b -> onClose())
            .bounds(left, top + 9 * 27 + 32, 380, 22).build());
    }

    @Override public void onClose() { minecraft.gui.setScreen(parent); }
}
