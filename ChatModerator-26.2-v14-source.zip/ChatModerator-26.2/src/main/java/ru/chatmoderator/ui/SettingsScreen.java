package ru.chatmoderator.ui;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ru.chatmoderator.ChatModeratorClient;
import ru.chatmoderator.config.ModConfig;

/** Small in-game settings panel. Changes are saved locally to config/chatmoderator.json. */
public final class SettingsScreen extends Screen {
    private final Screen parent;
    private final ModConfig config;

    public SettingsScreen(Screen parent, ModConfig config) {
        super(Component.literal("ChatModerator — настройки"));
        this.parent = parent;
        this.config = config;
    }

    @Override
    protected void init() {
        int x = this.width / 2 - 105;
        int y = this.height / 4;
        int w = 210;
        int h = 20;
        int gap = 25;

        addRenderableWidget(Button.builder(toggle("Сканирование", config.scannerEnabled), b -> {
            config.scannerEnabled = !config.scannerEnabled;
            b.setMessage(toggle("Сканирование", config.scannerEnabled));
            config.save();
        }).bounds(x, y, w, h).build());
        y += gap;
        addRenderableWidget(Button.builder(toggle("Чат игроков", config.inspectPlayerMessages), b -> {
            config.inspectPlayerMessages = !config.inspectPlayerMessages;
            b.setMessage(toggle("Чат игроков", config.inspectPlayerMessages));
            config.save();
        }).bounds(x, y, w, h).build());
        y += gap;
        addRenderableWidget(Button.builder(toggle("Сообщения сервера / tellraw", config.inspectServerMessages), b -> {
            config.inspectServerMessages = !config.inspectServerMessages;
            b.setMessage(toggle("Сообщения сервера / tellraw", config.inspectServerMessages));
            config.save();
        }).bounds(x, y, w, h).build());
        y += gap;
        addRenderableWidget(Button.builder(toggle("Уведомления в чате", config.showCandidatesInChat), b -> {
            config.showCandidatesInChat = !config.showCandidatesInChat;
            b.setMessage(toggle("Уведомления в чате", config.showCandidatesInChat));
            config.save();
        }).bounds(x, y, w, h).build());
        y += gap;
        addRenderableWidget(Button.builder(toggle("Отправка в Discord", config.uploadEvidenceToDiscord), b -> {
            config.uploadEvidenceToDiscord = !config.uploadEvidenceToDiscord;
            b.setMessage(toggle("Отправка в Discord", config.uploadEvidenceToDiscord));
            config.save();
        }).bounds(x, y, w, h).build());
        y += gap;
        addRenderableWidget(Button.builder(Component.literal("Просмотреть найденные сообщения"), b -> {
            this.minecraft.gui.setScreen(new ReviewScreen(this));
        }).bounds(x, y, w, h).build());
        y += gap;
        String[] ids = {"3.1","3.2","3.3","3.4","3.5","3.6","3.7","3.8","3.9","3.10"};
        String[] names = {"Оскорбления","КАПС","Родственники","Флуд","Реклама","Критика сервера","Выдача за персонал","Политика/рознь","Провокации","Попрошайничество"};
        int colW = 150;
        for (int i = 0; i < ids.length; i++) {
            final String id = ids[i];
            final String name = names[i];
            int col = i % 2;
            int row = i / 2;
            int bx = this.width / 2 - colW - 5 + col * (colW + 10);
            int by = y + row * 23;
            addRenderableWidget(Button.builder(ruleToggle(id, name), b -> {
                config.setRuleEnabled(id, !config.isRuleEnabled(id));
                b.setMessage(ruleToggle(id, name));
            }).bounds(bx, by, colW, 20).build());
        }
        y += 5 * 23 + 5;
        addRenderableWidget(Button.builder(Component.literal("Сохранить и закрыть"), b -> {
            config.save();
            onClose();
        }).bounds(x, y, w, h).build());
    }

    private Component ruleToggle(String id, String name) {
        return Component.literal(id + " " + name + ": " + (config.isRuleEnabled(id) ? "ВКЛ" : "ВЫКЛ"));
    }

    private static Component toggle(String name, boolean enabled) {
        return Component.literal(name + ": " + (enabled ? "ВКЛ" : "ВЫКЛ"));
    }

    @Override
    public void onClose() {
        config.save();
        this.minecraft.gui.setScreen(parent);
    }
}
