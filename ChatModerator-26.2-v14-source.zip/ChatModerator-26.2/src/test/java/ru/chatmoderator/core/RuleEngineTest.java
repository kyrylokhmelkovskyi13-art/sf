package ru.chatmoderator.core;

import java.util.List;

/** Dependency-free regression checks; run with the project classes on the classpath. */
public final class RuleEngineTest {
    private static final RuleEngine ENGINE = new RuleEngine();
    private static int passed;

    public static void main(String[] args) {
        expect("uppercase", has("3.2", ENGINE.inspect("ПРИВЕТ ВСЕМ ИГРОКАМ", null)));
        expect("uppercase threshold is strict", !has("3.2", ENGINE.inspect("ПРИВЕТ всем", null)));
        expect("hidden filter notice ignored", ENGINE.inspect("Сообщения скрытые фильтром", null).isEmpty());
        expect("configured exception suppresses insult root", !has("3.1", ENGINE.inspect("ты ебан", null, "tester", List.of("ебан"))));
        expect("same message repetition", has("3.4", ENGINE.inspect("привет", "привет")));
        expect("different previous message", !has("3.4", ENGINE.inspect("привет", "пока")));
        expect("invite link", has("3.5", ENGINE.inspect("заходи discord.gg/example", null)));
        expect("begging phrase", has("3.10", ENGINE.inspect("дай мне денег", null)));
        expect("ordinary greeting", ENGINE.inspect("Всем добрый вечер!", null).isEmpty());
        expect("configured exception is exact token", !has("3.1", ENGINE.inspect("ты нуб", null, "tester", List.of("нуб"))));
        expect("exception does not hide a different insult", has("3.1", ENGINE.inspect("ты нуб и мразь", null, "tester", List.of("нуб"))));
        expect("uppercase Unicode is counted", has("3.2", ENGINE.inspect("ЖЖЖЖЖЖЖЖЖЖ", null)));
        System.out.println("RuleEngine checks passed: " + passed);
    }

    private static boolean has(String id, List<Violation> violations) {
        return violations.stream().anyMatch(v -> v.ruleId().equals(id));
    }

    private static void expect(String name, boolean ok) {
        if (!ok) throw new AssertionError("FAILED: " + name);
        passed++;
    }
}
