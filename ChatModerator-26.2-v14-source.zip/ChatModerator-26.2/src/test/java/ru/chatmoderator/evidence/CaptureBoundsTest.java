package ru.chatmoderator.evidence;

import java.awt.Rectangle;

/** Headless geometry tests for F7 coordinate conversion. */
public final class CaptureBoundsTest {
    private static int passed;
    public static void main(String[] args) {
        Rectangle win = new Rectangle(100, 50, 1600, 900);
        eq("2x scale", new Rectangle(300, 150, 400, 200), CaptureBounds.fromGui(win, 800, 450, 100, 50, 300, 150));
        eq("reverse drag", new Rectangle(300, 150, 400, 200), CaptureBounds.fromGui(win, 800, 450, 300, 150, 100, 50));
        eq("clamp to window", new Rectangle(1500, 850, 200, 100), CaptureBounds.fromGui(win, 800, 450, 700, 400, 900, 500));
        eq("fractional scale rounds outward", new Rectangle(101, 51, 4, 4), CaptureBounds.fromGui(new Rectangle(100,50,1000,700), 667, 467, 1,1,3,3));
        eq("invalid scale", new Rectangle(), CaptureBounds.fromGui(win, 0, 450, 1,1,10,10));
        System.out.println("CaptureBounds checks passed: " + passed);
    }
    private static void eq(String name, Rectangle expected, Rectangle actual) {
        if (!expected.equals(actual)) throw new AssertionError(name + ": expected " + expected + ", got " + actual);
        passed++;
    }
}
